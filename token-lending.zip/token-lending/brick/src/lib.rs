#![deny(missing_docs)]

//! A brick.

pub use solana_program;

solana_program::declare_id!("So1endDq2YkqhipRh3WViPa8hdiSpxWy6z3Z6tMCpAo");

pub mod entrypoint;
